//导入数据库模块
var mongoose = require('mongoose')

//mongodb : 协议      localhost : 本地ip   
//local : 一个本地数据库的名称
//连接到mongoDB服务器中的某个数据库
mongoose.connect('mongodb://localhost/local')

//获取数据库(用一个变量指向连接到的数据库)
var db = mongoose.connection 

//监听打开数据库失败的事件
db.on('error',function(){
	console.log('连接数据库失败')
})

//数据库打开成功的事件
db.once('open',function(){
	console.log('连接数据库成功,并打开数据库')
	//打开数据库之后就可以执行各项操作了
})

function insert(){
	
	//向数据库的集合中添加一个文档/数据
	
	//设置模式    Schema 模式
	//说明向集合中插入的文档有哪些属性,分别是什么类型
	var studentSchema = mongoose.Schema({
		name : String ,
		age : Number ,
		sex : Boolean ,
		birth : Date
	})
//	console.log(studentSchema)
	
	//设置一个数据模型(构造函数),类似于数据库中的集合
	var Students = mongoose.model('students',studentSchema)
	
	//用模型创建一个对象,类似集合中的文档
	var zhangsan = new Students({
		name : '张三',
		age : 100 ,
		sex : true ,
		birth : new Date(1999,10,20)
	})
	
	//把对象存入数据库的集合中
	zhangsan.save(function(error,zhangsan){
		//参数一是错误信息,参数二是存入的数据
		if(!error){
			console.log('数据保存成功')
		}
	})
}

function find(){
	var studentSchema = mongoose.Schema({
		name : String ,
		age : Number ,
		sex : Boolean ,
		birth : Date
	})
	
	var Students = mongoose.model('students',studentSchema)
	
	//无条件查询         execute 执行
	Students.find().exec(function(error,data){
		console.log('查询数据')
		if(!error){console.log(data)}
	})

	//条件查询
//	Students.find({sex:true}).exec(function(error,data){
//		console.log('查询数据')
//		if(!error){console.log(data)}
//	})
	
	//通过ID查询数据
//	Students.findById('58c65c9b8d60452bfcdc7653').exec(function(error,data){
//		console.log(data)
//	})
}

//在同一时刻有两个地方打开同一个集合会造成冲突

function remove(){
	
	var studentSchema = mongoose.Schema({
		name : String ,
		age : Number ,
		sex : Boolean ,
		birth : Date
	})
	
	var Students = mongoose.model('students',studentSchema)
	
	//把满足条件的文档/数据全部删除
	Students.remove({age:100},function(error){
		if(!error){console.log('删除成功')}
	})
	

}

function update(){
	
	var studentSchema = mongoose.Schema({
		name : String ,
		age : Number ,
		sex : Boolean ,
		birth : Date
	})
	
	var Students = mongoose.model('students',studentSchema)
	
//	更新操作,

	Students.update({name:'张三'},{age:20,sex:false}, {multi: true}, function(error){
		if(!error){console.log('修改数据成功')}
	})
	
	
	//通过id更新数据
//	Students.findByIdAndUpdate('58c6648c28eb520a7cd047ac',{age:50,sex:false},function(){
//		console.log('修改数据成功')
//	})

	
}



//1,增
//  insert()

//2,删
//	remove()

//3,改
//  update()

//4,查
    find()


