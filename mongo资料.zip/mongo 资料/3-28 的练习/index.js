var Student = require('./studentCollections');
var express = require('express');
var app = express();
var student = new Student({
    name: 'zhangsan',
    age: 15,
    phone: 17362352418,
    introduce: '1232asdasd'
});
console.log(student);
student.save(function (error, doc) {
    if (!error) {
        console.log('doc', doc);
    }
});
app.listen(5000, function () {
    console.log('running');
});
